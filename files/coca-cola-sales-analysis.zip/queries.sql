-- name: annual_growth
SELECT year,
       revenue_musd,
       ROUND(100.0 * (revenue_musd - LAG(revenue_musd) OVER (ORDER BY year))
             / LAG(revenue_musd) OVER (ORDER BY year), 2) AS yoy_pct
FROM annual
ORDER BY year;

-- name: seasonality
SELECT q.quarter,
       ROUND(AVG(100.0 * q.revenue_musd / a.revenue_musd), 2) AS avg_share_of_year_pct
FROM quarterly q
JOIN annual a ON a.year = q.year
GROUP BY q.quarter
ORDER BY q.quarter;

-- name: rolling_ttm
SELECT year, quarter, ttm_musd
FROM (
    SELECT year, quarter,
           SUM(revenue_musd) OVER w AS ttm_musd,
           COUNT(*)          OVER w AS n
    FROM quarterly
    WHERE year <= 2025
    WINDOW w AS (ORDER BY year, quarter ROWS BETWEEN 3 PRECEDING AND CURRENT ROW)
)
WHERE n = 4
ORDER BY year, quarter;

-- name: gross_margin
SELECT g.year,
       a.revenue_musd,
       g.gross_profit_musd,
       ROUND(100.0 * g.gross_profit_musd / a.revenue_musd, 1) AS gross_margin_pct
FROM gross_profit g
JOIN annual a ON a.year = g.year
ORDER BY g.year;

-- name: ytd_comparison
SELECT year,
       revenue_musd,
       ROUND(100.0 * (revenue_musd - LAG(revenue_musd) OVER (ORDER BY year))
             / LAG(revenue_musd) OVER (ORDER BY year), 2) AS revenue_growth_pct,
       ROUND(100.0 * gross_profit_musd / revenue_musd, 1)          AS gross_margin_pct,
       ROUND(100.0 * consolidated_net_income_musd / revenue_musd, 1) AS net_margin_pct
FROM ytd
ORDER BY year;

-- name: best_and_worst_quarters
SELECT year, quarter, revenue_musd FROM quarterly ORDER BY revenue_musd DESC LIMIT 3;
